from distutils.core import setup

setup(
    name = 'common',
    version = '1.0',
    description = 'common library',
    author = 'liuyuan',
    packages = ['common'],
)