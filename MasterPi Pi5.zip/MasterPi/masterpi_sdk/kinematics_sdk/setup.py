from distutils.core import setup

setup(
    name = 'kinematics',
    version = '1.0',
    description = 'kinematics library',
    author = 'liuyuan',
    packages = ['kinematics'],

)